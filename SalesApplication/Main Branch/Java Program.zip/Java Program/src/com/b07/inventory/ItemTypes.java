package com.b07.inventory;

public enum ItemTypes {
  FISHING_ROD,
  HOCKEY_STICK,
  SKATES,
  RUNNING_SHOES,
  PROTEIN_BAR

}
