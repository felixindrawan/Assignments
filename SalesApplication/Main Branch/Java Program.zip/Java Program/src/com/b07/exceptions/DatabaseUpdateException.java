package com.b07.exceptions;

public class DatabaseUpdateException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

}
