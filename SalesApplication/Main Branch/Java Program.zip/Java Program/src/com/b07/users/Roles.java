package com.b07.users;

public enum Roles {
  ADMIN,
  EMPLOYEE,
  CUSTOMER

}
